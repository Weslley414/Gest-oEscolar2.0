import mysql from "mysql2/promise";

const pool = mysql.createPool({
  host: "edumysql.acesso.rj.senac.br",
  port: 3306,
  user: "20252_prjint5",
  password: "Senac@2025",
  database: "20252_prjint5_josebispo",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

console.log("Conectado ao banco de dados MySQL!");


export default pool;
